#define bar with,embedded,commas
#define function(x) success
#define foo function
foo(bar)
