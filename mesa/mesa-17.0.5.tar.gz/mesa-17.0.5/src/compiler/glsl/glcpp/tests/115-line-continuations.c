// This comment continues to the next line, hiding the define \
#define CONTINUATION_UNSUPPORTED

#ifdef CONTINUATION_UNSUPPORTED
failure
#else
success
#endif

