success_1
#if 1
success_2
#elif 0
failure_1
#elif 1
failure_2
#elif 0
failure_3
#endif
success_3
