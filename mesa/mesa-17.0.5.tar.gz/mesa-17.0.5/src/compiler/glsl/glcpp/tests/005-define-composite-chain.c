#define foo 1
#define bar a foo
bar
