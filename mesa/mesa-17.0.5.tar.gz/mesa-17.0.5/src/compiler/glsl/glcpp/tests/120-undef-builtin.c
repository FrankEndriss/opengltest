#version 300 es
#undef __LINE__
#undef __FILE__
#undef __VERSION__
